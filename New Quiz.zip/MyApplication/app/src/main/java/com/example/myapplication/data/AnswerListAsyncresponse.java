package com.example.myapplication.data;

import com.example.myapplication.model.question;

import java.util.ArrayList;

public interface AnswerListAsyncresponse {
void processfinished(ArrayList<question>questionArrayList);
}
