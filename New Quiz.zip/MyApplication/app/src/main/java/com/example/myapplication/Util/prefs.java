package com.example.myapplication.Util;

import android.app.Activity;
import android.content.SharedPreferences;

public class prefs {
    private SharedPreferences preferences;
    public prefs(Activity activity)
    {
        this.preferences=activity.getPreferences(activity.MODE_PRIVATE);
    }
    public void savehighscore(int score)
    {
       int currentscore=score;
       int lastscore=preferences.getInt("high score",0);
       if(currentscore>lastscore)
       {
           preferences.edit().putInt("high score",currentscore).apply();
       }
    }
    public int gethighscore()
    {
       return preferences.getInt("high score",0);
    }
    public void setstate(int index)
    {
        preferences.edit().putInt("index state",index).apply();
    }
    public int getstate()
    {
        return preferences.getInt("index state",0);
    }
}
