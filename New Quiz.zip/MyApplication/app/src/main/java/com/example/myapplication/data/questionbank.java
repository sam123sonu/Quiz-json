package com.example.myapplication.data;

import android.util.Log;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonRequest;
import com.example.myapplication.controller.Appcontroller;
import com.example.myapplication.model.question;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

import static com.example.myapplication.controller.Appcontroller.TAG;

public class questionbank {
private String url=" https://raw.githubusercontent.com/curiousily/simple-quiz/master/script/statements-data.json";

ArrayList<question> questionArrayList= new ArrayList<>();
 public List<question> getquestion(final AnswerListAsyncresponse callBack) {
     JsonArrayRequest jsonArrayRequest=new JsonArrayRequest(
             Request.Method.GET,
             url,
             (JSONArray) null,
             new Response.Listener<JSONArray>() {
                 @Override
                 public void onResponse(JSONArray response) {
                     for (int i = 0; i < response.length(); i++) {
                         try { question question= new question();
                             question.setAnswer(response.getJSONArray(i).get(0).toString());
                             question.setAnswertrue(response.getJSONArray(i).getBoolean(1));
                             //adding question to the arraylist...
                             questionArrayList.add(question);
                             //Log.d("json", "onResponse: "+response.getJSONArray(i).get(0));
                             //Log.d("json1", "onResponse: "+response.getJSONArray(i).getBoolean(1));
                         } catch (JSONException e) {
                             e.printStackTrace();
                         }
                     }
                     if(null!=callBack) callBack.processfinished(questionArrayList);
                 }
             }, new Response.ErrorListener() {
         @Override
         public void onErrorResponse(VolleyError error) {

         }
     });
     Appcontroller.getInstance().addToRequestQueue(jsonArrayRequest);
     return questionArrayList;
 }

}
