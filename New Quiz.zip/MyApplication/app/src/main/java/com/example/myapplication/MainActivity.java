package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication.Util.prefs;
import com.example.myapplication.data.AnswerListAsyncresponse;
import com.example.myapplication.data.questionbank;
import com.example.myapplication.model.question;

import java.util.ArrayList;
import java.util.List;

public class MainActivity<Prefs> extends AppCompatActivity implements View.OnClickListener {
    private TextView questiontextview;
    private TextView questioncounter;
    private Button truebutton;
    private Button falsebutton;
    private ImageButton nextbutton;
    private ImageButton prevbutton;
    private List<question> questionList;
    private int currentquestionindex;
    private int score=0;
    private TextView Score;
    private prefs prefs;
    private TextView highscore;
    private static  int SPLASH_TIME_OUT=1500;
    private CardView cardView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs=new prefs(MainActivity.this);
        Log.d("second", "onClick: "+prefs.gethighscore());

        nextbutton=findViewById(R.id.next_button);
        prevbutton=findViewById(R.id.prev_button);
        truebutton=findViewById(R.id.true_button);
        falsebutton=findViewById(R.id.false_button);
        questiontextview=findViewById(R.id.question_textview);
        questioncounter=findViewById(R.id.question_counter);
        Score=findViewById(R.id.q_score);
        highscore=findViewById(R.id.hgh_score);
        cardView=findViewById(R.id.cardView);
        highscore.setText("high score:"+String.valueOf(prefs.gethighscore()));
        nextbutton.setOnClickListener(this);
        prevbutton.setOnClickListener(this);
        truebutton.setOnClickListener(this);
        falsebutton.setOnClickListener(this);
        currentquestionindex=prefs.getstate();
        questionList=new questionbank().getquestion(new AnswerListAsyncresponse() {
            @Override
            public void processfinished(ArrayList<question> questionArrayList) {
                questiontextview.setText(questionArrayList.get(currentquestionindex).getAnswer());
                questioncounter.setText((currentquestionindex+1)+"/"+questionList.size());
                Log.d("inside", "processfinished: "+questionArrayList);
            }
        });

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.prev_button:
                currentquestionindex=currentquestionindex-1;
                if(currentquestionindex<0) {
                    currentquestionindex = currentquestionindex + questionList.size();
                }

                cardView.setCardBackgroundColor(Color.WHITE);
                backquestion();
                break;
            case R.id.next_button:
                currentquestionindex=(currentquestionindex+1)%questionList.size();

                cardView.setCardBackgroundColor(Color.WHITE);

                updatequestion();
                break;
            case R.id.true_button:
                checkAnswer(true);
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        cardView.setCardBackgroundColor(Color.WHITE);
                        currentquestionindex=(currentquestionindex+1)%questionList.size();
                        updatequestion();
                    }
                },SPLASH_TIME_OUT);

                break;
            case R.id.false_button:
                checkAnswer(false);
                new Handler().postDelayed(new Runnable() {

                    @Override
                    public void run() {
                        cardView.setCardBackgroundColor(Color.WHITE);
                        currentquestionindex=(currentquestionindex+1)%questionList.size();
                        updatequestion();
                    }
                },SPLASH_TIME_OUT);

                break;
        }


    }

    private void checkAnswer(boolean userchoose) {
        boolean answer=questionList.get(currentquestionindex).isAnswertrue();
        int toastMessageId=0;
        CardView cardView =findViewById(R.id.cardView);
        if(answer==userchoose) {
            toastMessageId=R.string.correct_answer;
            cardView.setCardBackgroundColor(Color.GREEN);
            shakeAnimation();
            score+=4;
            Score.setText("score:"+String.valueOf(score));
        } else {cardView.setCardBackgroundColor(Color.RED);
            toastMessageId = R.string.wrong_answer;
            fadeView();
            if(score>0)
            score-=2;
             Score.setText("score:"+String.valueOf(score));
        }
        Toast.makeText(MainActivity.this,toastMessageId,Toast.LENGTH_SHORT).show();
    }

    private void updatequestion() {

        String question=questionList.get(currentquestionindex).getAnswer();
        questiontextview.setText(question);
        questioncounter.setText((currentquestionindex+1)+"/"+questionList.size());

    }
    private void backquestion(){
        String question=questionList.get(currentquestionindex).getAnswer();
        questiontextview.setText(question);
        questioncounter.setText((currentquestionindex+1)+"/"+questionList.size());

    }
    private void shakeAnimation(){
        Animation shake= AnimationUtils.loadAnimation(MainActivity.this,R.anim.shake_animation);
        CardView cardView =findViewById(R.id.cardView);
        cardView.setAnimation(shake);
    }
    private void fadeView(){
        CardView cardView =findViewById(R.id.cardView);
        AlphaAnimation alphaAnimation= new AlphaAnimation(1.0f,0.0f);
        alphaAnimation.setDuration(350);
        alphaAnimation.setRepeatCount(2);
        alphaAnimation.setRepeatMode(Animation.REVERSE);

        cardView.setAnimation(alphaAnimation);
    }

    @Override
    protected void onPause() {
       prefs.savehighscore(score);
       prefs.setstate(currentquestionindex);
        super.onPause();

    }
}
